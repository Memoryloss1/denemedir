# main.py

from telegram import ParseMode, ReplyKeyboardMarkup, Update
from telegram.ext import CommandHandler, Filters, MessageHandler, CallbackContext
from utils import send_async
from user_setting import UserSetting
from group_setting import GroupSetting
from shared_vars import dispatcher
from locales import available_locales
from internationalization import _, user_locale
from database import session

@user_locale
def show_settings(update: Update, context: CallbackContext):
    chat = update.message.chat

    if update.message.chat.type != 'private':
        send_async(context.bot, chat.id, text=_("Lütfen ayarlarınızı botun özel sohbetinde düzenleyin."))
        return

    us = UserSetting.get(update.message.from_user.id)

    if not us:
        us = UserSetting(id=update.message.from_user.id)

    if not us.stats:
        stats = '📊' + ' ' + _("Enable statistics")
    else:
        stats = '❌' + ' ' + _("Delete all statistics")

    kb = [[stats], ['🌍' + ' ' + _("Language")]]
    send_async(context.bot, chat.id, text='🔧' + ' ' + _("Settings"),
               reply_markup=ReplyKeyboardMarkup(keyboard=kb, one_time_keyboard=True))


@user_locale
def kb_select(update: Update, context: CallbackContext):
    chat = update.message.chat
    user = update.message.from_user
    option = context.match[1]

    if option == '📊':
        us = UserSetting.get(user.id)
        us.stats = True
        send_async(context.bot, chat.id, text=_("Etkin istatistikler!"))

    elif option == '🌍':
        kb = [[locale + ' - ' + descr] for locale, descr in sorted(available_locales.items())]
        send_async(context.bot, chat.id, text=_("yerel ayarı seçin"), reply_markup=ReplyKeyboardMarkup(keyboard=kb, one_time_keyboard=True))

    elif option == '❌':
        us = UserSetting.get(user.id)
        us.stats = False
        us.first_places = 0
        us.games_played = 0
        us.cards_played = 0
        send_async(context.bot, chat.id, text=_("Silinen ve devre dışı bırakılan istatistikler!"))


@user_locale
def locale_select(update: Update, context: CallbackContext):
    chat = update.message.chat
    user = update.message.from_user
    option = context.match[1]

    if option in available_locales:
        us = UserSetting.get(user.id)
        us.lang = option
        _.push(option)
        send_async(context.bot, chat.id, text=_("Yerel ayar yapın!"))
        _.pop()


@user_locale
def show_top_users(update: Update, context: CallbackContext):
    chat = update.message.chat
    top_users = session.query(UserSetting).order_by(UserSetting.total_wins.desc()).limit(10).all()

    message = "🏆 Top 10 Users 🏆\n\n"
    for i, user in enumerate(top_users):
        message += f"{i+1}. User ID: {user.id} - Wins: {user.total_wins} - Games: {user.total_games}\n"

    send_async(context.bot, chat.id, text=message, parse_mode=ParseMode.HTML)


@user_locale
def show_top_groups(update: Update, context: CallbackContext):
    chat = update.message.chat
    top_groups = session.query(GroupSetting).order_by(GroupSetting.total_games.desc()).limit(10).all()

    message = "🏆 Top 10 Groups 🏆\n\n"
    for i, group in enumerate(top_groups):
        message += f"{i+1}. Group ID: {group.id} - Games: {group.total_games} - Wins: {group.total_wins}\n"

    send_async(context.bot, chat.id, text=message, parse_mode=ParseMode.HTML)


def register():
    dispatcher.add_handler(CommandHandler('settings', show_settings))
    dispatcher.add_handler(CommandHandler('topusers', show_top_users))
    dispatcher.add_handler(CommandHandler('topgroups', show_top_groups))
    dispatcher.add_handler(MessageHandler(Filters.regex('^([' + '📊' + '🌍' + '❌' + ']) .+$'), kb_select))
    dispatcher.add_handler(MessageHandler(Filters.regex(r'^(\w\w_\w\w) - .*'), locale_select))
