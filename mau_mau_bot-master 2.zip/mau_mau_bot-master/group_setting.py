# group_setting.py

from sqlalchemy import Column, Integer, String
from database import Base

class GroupSetting(Base):
    __tablename__ = 'group_settings'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    total_games = Column(Integer, default=0)
    total_wins = Column(Integer, default=0)

# Diğer gerekli metotlar ve işlemler...
