#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Telegram bot to play UNO in group chats
# Copyright (c) 2016 Jannes Höke <uno@jhoeke.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


from pony.orm import Optional, PrimaryKey
from database import db

# user_setting.py

from sqlalchemy import Column, Integer, String, Boolean
from database import Base  # Bu şekilde Base'ı doğru bir şekilde içe aktarın

class UserSetting(Base):
    __tablename__ = 'user_settings'
    id = Column(Integer, primary_key=True)
    lang = Column(String)
    stats = Column(Boolean, default=False)
    first_places = Column(Integer, default=0)
    games_played = Column(Integer, default=0)
    cards_played = Column(Integer, default=0)
    total_wins = Column(Integer, default=0)
    total_games = Column(Integer, default=0)

    @staticmethod
    def get(user_id):
        # Veritabanı oturumunu burada kullanın ve kullanıcıyı alın
        return session.query(UserSetting).filter_by(id=user_id).first()


class UserSetting(db.Entity):
    

    id = PrimaryKey(int, auto=False, size=64)  # Telegram User ID
    lang = Optional(str, default='tr')  # The language setting for this user
    stats = Optional(bool, default=True)  # Opt-in to keep game statistics
    first_places = Optional(int, default=0)  # Nr. of games won in first place
    games_played = Optional(int, default=0)  # Nr. of games completed
    cards_played = Optional(int, default=0)  # Nr. of cards played total
    use_keyboards = Optional(bool, default=False)  # Use keyboards (unused)


