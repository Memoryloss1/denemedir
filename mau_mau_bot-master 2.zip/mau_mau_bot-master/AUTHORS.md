# Credits

`mau_mau_bot` is written and maintained by [Jannes Höke](https://github.com/jh0ker)

## Contributors

The following wonderful people contributed directly or indirectly to this project:

- [imlonghao](https://github.com/imlonghao)
- [Iuri Guilherme](https://github.com/iuriguilherme)
- [pan93412](https://github.com/pan93412)
- [qubitnerd](https://github.com/qubitnerd)
- [SYHGroup](https://github.com/SYHGroup)

Please add yourself here alphabetically when you submit your first pull request.
